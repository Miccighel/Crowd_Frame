const AWS = require('aws-sdk');
const http = require('http');
const https = require('https');

let dynamodb = new AWS.DynamoDB.DocumentClient();
let s3 = new AWS.S3()

let bucket = 'crowd-page-log'
let task = '';
let batch = '';
let worker = '';

exports.handler = (event) => {
    for (const msg of event.Records) {
        let data = JSON.parse(msg['body']);
        let seq = data['sequence']
        task = data['task'];
        batch = data['batch'];
        worker = data['worker'];
        data['server_time'] = Date.now();

        if (data['type'] === 'queryResults') {
            let index = 0;
            for (const url of data['details']['urlArray']) {
                let key = task + "/" + batch + "/" + worker + "/page_" + index.toString() + ".html";
                let content = "";
                let protocol = url.split(':')[0]
                let client = getClient(protocol)
                let req = client.request(url, (res) => {
                    res.setEncoding("utf8");
                    res.on("data", function (chunk) {
                        content += chunk;
                    });

                    res.on("end", function () {
                        s3.putObject({Bucket: bucket, Key: key, Body: content}, (err, data) => {
                            if (err) console.log(err, err.stack);
                        });
                    });
                });
                req.end();
                index++;
            }
            data['details'] = JSON.stringify(data['details'])
            writeToDB(data, seq, 1);
        } else if (data['type'] === 'context') {
            let ip = data['details']['ip'];
            lookup(ip).then(details => {
                if (JSON.stringify(details) != "{}")
                    data['details'] = details
                data['details'] = JSON.stringify(data['details'])
                writeToDB(data, seq, 1);
            }).catch(
                function (err) {
                    console.error(err, err.stack);
                }
            );
        } else {
            data['details'] = JSON.stringify(data['details'])
            writeToDB(data, seq, 1);
        }
    }
}

function getClient(protocol) {
    if (protocol === 'http') return http
    else return https
}

function writeToDB(data, seq, tryNum) {
    data['sequence'] = tryNum.toString() + "_" + seq.toString()
    let table_name = "Crowd_Frame-" + task + "_" + batch + "_Logger";
    dynamodb.put({
        Item: data,
        TableName: table_name,
        ConditionExpression: "attribute_not_exists(worker)"
    }, (error) => {
        if (error) {
            writeToDB(data, seq, ++tryNum)
        }
    });
}

function lookup(ip) {
    let url = 'https://ip-api.com/json/' + ip + '?fields=continentCode,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,reverse,mobile,proxy,hosting';
    return new Promise((resolve, reject) =>
        https.get(url, res => {
            let data = ''
            res.on('data', (chunk) => {
                data += chunk
            });
            res.on('end', () => {
                resolve(JSON.parse(data))
            });
        })
    );
}
